public class Variables {
    public static void main(String[] args) {
        //Declarando una variable
        int speed;
        //Asignamos un valor a una variable
        speed = 10;
        System.out.println(speed);

        int salary = 1000;
        String employeeName = "Anahí Salgado";
        System.out.println(employeeName);

    }
}
