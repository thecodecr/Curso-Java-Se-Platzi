             //Upper Camel Case
public class NamingJava {
    public static void main(String[] args) {
        int celphone = 33337777;
        int celPhone = 55553333;
        System.out.println(celphone);
        System.out.println(celPhone);

        String $countryName = "Spain";
        String _backgroundColor = "Green";

        String currency$ = "MXN";
        String background_color = "BLUE";

        int POSITION = -5;
        int MAX_WIDTH = 9999;
        int MIN_WIDTH = 1;

        //Lower Camel Case
        String fullName = "Irene Anahi Salgado Díaz de la Vega";
        int sizeInCentimeters = 26;


    }
}
